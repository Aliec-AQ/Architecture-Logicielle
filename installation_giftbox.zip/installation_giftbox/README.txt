Pour installer : 
- avoir docker d'installé 
- faire la commande : docker compose up -d, dans le repertoire où se situe le fichier docker-compose.yml
- aller sur le lien pour l'app : https://localhost:4001
- aller sur le lien pour l'api : https://localhost:4002

- modifier les ports si besoin
