<?php
namespace gift\api\core\services\catalogue;
class CatalogueServiceNotFoundException extends \Exception{}