<?php
namespace gift\api\core\services\box;

class BoxServiceNotFoundException extends \Exception{}