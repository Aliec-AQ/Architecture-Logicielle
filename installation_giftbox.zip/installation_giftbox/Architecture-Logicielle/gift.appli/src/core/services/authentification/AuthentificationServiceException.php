<?php
namespace gift\appli\core\services\authentification;
class AuthentificationServiceException extends \Exception{}