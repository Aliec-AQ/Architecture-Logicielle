<?php
namespace gift\appli\core\services\catalogue;
class CatalogueServiceNotFoundException extends \Exception{}