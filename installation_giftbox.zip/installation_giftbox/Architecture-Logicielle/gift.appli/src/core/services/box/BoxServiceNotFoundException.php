<?php
namespace gift\appli\core\services\box;

class BoxServiceNotFoundException extends \Exception{}